# SD-Portfolio-Bootstrap

Hieronder volgen de sprints voor de komende 4 weken. 
Deze sprints maak je door gebruik te maken van de powerpoints in lesmateriaal. De powerpoints bevatten meer informatie.

Sprint 1:
- Voeg Bootstrap toe aan de pagina
    - Push de oefening, met de commit message: "sprint 1 starter"
- Voeg grid toe, maak de bloemen pagina na in de powerpoint
    - Push de oefening, met de commit message: "sprint 1 grid"

Portfolio opdracht: Bekijk je portfolio, voeg de Bootstrap elementen van deze les eraan toe.

Sprint 2: 
- Voeg tabellen toe
    - Push de oefening, met de commit message: "sprint 2 tabel"
- Voeg images toe
    - Push de oefening, met de commit message: "sprint 2 image"
- Voeg jumboton toe
    - Push de oefening, met de commit message: "sprint 2 jumboton"
- Voeg een alert toe
    - Push de oefening, met de commit message: "sprint 2 alert"

Portfolio opdracht: Bekijk je portfolio, voeg de Bootstrap elementen van deze les eraan toe.

Spint 3: 
- Voeg cards toe
    - Push de oefening, met de commit message: "sprint 3 cards"
- Voeg een list group toe
    - Push de oefening, met de commit message: "sprint 3 list"

Portfolio opdracht: Bekijk je portfolio, voeg de Bootstrap elementen van deze les eraan toe.

Sprint 4: 
- Voeg een navigatie balk toe
    - Push de oefening, met de commit message: "sprint 4 nav"
- Voeg carousel toe
    - Push de oefening, met de commit message: "sprint 4 carousel"
- Voeg pagination
    - Push de oefening, met de commit message: "sprint 4 pagination"

Portfolio opdracht: Bekijk je portfolio, voeg de Bootstrap elementen van deze les eraan toe.


