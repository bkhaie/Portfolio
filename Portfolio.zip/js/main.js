function bloemen() {
	var txt;
	if (confirm("Wilt u echt naar een ander pagina?")) document.location = "Projecten/Bloemenwinkel/Sprint1.html"; {
	}
  }

function Rekenmachine() {
var txt;
if (confirm("Wilt u echt naar een ander pagina?")) document.location = "Projecten/Rekenmachine/Calculator Project/Calculator v3/MijnErvaringen.html"; {
}}


function boterkaas() {
	var txt;
	if (confirm("Wilt u echt naar een ander pagina?")) document.location = "Projecten/BKE/index.html"; {
}}





 function dicespel(){
  const password = prompt('Voer het wachtwoord in:');
  if(password.toLowerCase() == "khaie"){
    window.open("Projecten/Dicegame/dicegame.7z")    
  }else{
    alert("Foute wachtwoord!! Probeer opnieuw");
  }
}

function kaartspel(){
	const password = prompt('Voer het wachtwoord in:');
	if(password.toLowerCase() == "khaie"){
	  window.open("Projecten/Hoger-Lager-main/Hoger-Lager-main.7z")    
	}else{
	  alert("Foute wachtwoord!! Probeer opnieuw");
	}
  }






